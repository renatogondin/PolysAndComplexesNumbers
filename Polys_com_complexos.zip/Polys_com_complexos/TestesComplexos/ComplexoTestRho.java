import static org.junit.Assert.*;

import org.junit.Test;

public class ComplexoTestRho {

	private double expected;
	private double actual;
	
	@Test
	public void testIm1() {
		
		Complexo x = new Complexo(0, 1);
		expected = 1;
		actual = x.rho();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testIm2() {
		
		Complexo x = new Complexo(1, 1);
		expected = 1.4142135;
		actual = x.rho();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testIm3() {
		
		Complexo x = new Complexo(0, 0);
		expected = 0;
		actual = x.rho();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testIm4() {
		
		Complexo x = new Complexo(0, -1);
		expected = 1;
		actual = x.rho();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testIm5() {
		
		Complexo x = new Complexo(3, -1);
		expected = 3.162277;
		actual = x.rho();
		
		assertEquals(expected, actual, 0.000001);
		
	}

}
