import static org.junit.Assert.*;

import org.junit.Test;

public class ComplexoTestEhZero {

	private boolean expected;
	private boolean actual;
	
	@Test
	public void testehZero1() {
		
		Complexo um = new Complexo(0, 1);
		expected = false;
		actual = um.ehZero();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testehZero2() {
		
		Complexo um = new Complexo(1, 0);
		expected = false;
		actual = um.ehZero();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testehZero3() {
		
		Complexo um = new Complexo(0.000000000001, 0.00000000000001);
		expected = true;
		actual = um.ehZero();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testehZero4() {
		
		Complexo um = new Complexo(2, 3);
		expected = false;
		actual = um.ehZero();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testehZero5() {
		
		Complexo um = new Complexo(Complexo.ERRO, Complexo.ERRO);
		expected = true;
		actual = um.ehZero();
		
		assertEquals(expected,actual);
		
	}
	
	
	@Test
	public void testehZero6() {
		
		Complexo um = new Complexo(-2,0);
		expected = false;
		actual = um.ehZero();
				
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testehZero7() {
		
		Complexo um = new Complexo(-2, 0.00000001);
		expected = false;
		actual = um.ehZero();
				
		assertEquals(expected,actual);
		
	}

}
