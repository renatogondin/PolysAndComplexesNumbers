import static org.junit.Assert.*;

import org.junit.Test;

public class ComplexoTestEhReal {

	private boolean expected;
	private boolean actual;
	
	@Test
	public void testEhReal1() {
		
		Complexo um = new Complexo(0, 1);
		expected = false;
		actual = um.ehReal();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhReal2() {
		
		Complexo um = new Complexo(1, 0);
		expected = true;
		actual = um.ehReal();		

		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhReal3() {
		
		Complexo um = new Complexo(1.000000000001, 0.00000000000001);
		expected = true;
		actual = um.ehReal();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhReal4() {
		
		Complexo um = new Complexo(2, 3);
		expected = false;
		actual = um.ehReal();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhReal5() {
		
		Complexo um = new Complexo(1.000000000001, Complexo.ERRO);
		expected = true;
		actual = um.ehReal();
		
		assertEquals(expected,actual);
		
	}
	
	
	@Test
	public void testEhReal6() {
		
		Complexo um = new Complexo(-2,0);
		expected = true;
		actual = um.ehReal();
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhReal7() {
		
		Complexo um = new Complexo(-2, 0.00000001);
		expected = true;
		actual = um.ehReal();
		
		assertEquals(expected,actual);
		
	}

}
