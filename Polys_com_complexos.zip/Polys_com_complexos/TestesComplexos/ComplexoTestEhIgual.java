import static org.junit.Assert.*;

import org.junit.Test;

public class ComplexoTestEhIgual {

	private boolean expected;
	private boolean actual;
	
	@Test
	public void testEhIgual1() {
		
		Complexo um = new Complexo(0, 1);
		Complexo outro = new Complexo(0, 1);
		expected = true;
		actual = um.ehIgual(outro);
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhIgual2() {
		
		Complexo um = new Complexo(1, 0);
		Complexo outro = new Complexo(0, 1);
		expected = false;
		actual = um.ehIgual(outro);
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhIgual3() {
		
		Complexo um = new Complexo(1.000000000001, 5.00000000000001);
		Complexo outro = new Complexo(1, 5);
		expected = true;
		actual = um.ehIgual(outro);
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhIgual4() {
		
		Complexo um = new Complexo(2, 3);
		Complexo outro = new Complexo(2, 3.0001);
		expected = false;
		actual = um.ehIgual(outro);
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhIgual5() {
		
		Complexo um = new Complexo(2, 3);
		Complexo outro = new Complexo(3, 2);
		expected = false;
		actual = um.ehIgual(outro);
		
		assertEquals(expected,actual);
		
	}
	
	
	@Test
	public void testEhIgual6() {
		
		Complexo um = new Complexo(-2, 3);
		Complexo outro = new Complexo(-2, 3);
		expected = true;
		actual = um.ehIgual(outro);
		
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testEhIgual7() {
		
		Complexo um = new Complexo(2, -3);
		Complexo outro = new Complexo(2.00000000001, -3.00000000001);
		expected = true;
		actual = um.ehIgual(outro);
		
		assertEquals(expected,actual);
		
	}

}
