import static org.junit.Assert.*;

import org.junit.Test;

public class ComplexoTestNorma {

	private double expected;
	private double actual;
	
	@Test
	public void testNorma1() {
		
		Complexo x = new Complexo(0, 1);
		expected = 1;
		actual = x.norma();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testNorma2() {
		
		Complexo x = new Complexo(4, 3);
		expected = 5;
		actual = x.norma();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testNorma3() {
		
		Complexo x = new Complexo(-3, 4);
		expected = 5;
		actual = x.norma();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testNorma4() {
		
		Complexo x = new Complexo(-4, -3);
		expected = 5;
		actual = x.norma();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testNorma5() {
		
		Complexo x = new Complexo(3, -4);
		expected = 5;
		actual = x.norma();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testNorma6() {
		
		Complexo x = new Complexo(0,0);
		expected = 0;
		actual = x.norma();
		
		assertEquals(expected, actual, 0.000001);
		
	}
	
	@Test
	public void testNorma7() {
		
		Complexo x = new Complexo(1, 0);
		expected = 1;
		actual = x.norma();
		
		assertEquals(expected, actual, 0.000001);
		
	}

}
