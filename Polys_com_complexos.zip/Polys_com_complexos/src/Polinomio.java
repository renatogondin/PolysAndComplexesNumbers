// Nao se esqueca de comentar a classe!
public class Polinomio {

	public Polinomio(Complexo[] coefs) {

	}

	public int grau() {
		return 0;
	}


	public boolean ehZero() {
		return true;
	}

	public boolean ehConstante() {
		return true;
	}

	public Polinomio escalar(Complexo f) {
		return null;     
	}

	public Polinomio simetrico() {
		return null;
	}

	public Polinomio soma (Polinomio p) {
		return null;	
	}

	public Polinomio subtraccao (Polinomio p) {
		return null;
	}

	public Polinomio produto(Polinomio p) {
		return null;
	}

	public Complexo avalia(Complexo x) {
		return null;
	}

	
	public Polinomio copia() {
		return null;
	}


	public String toString() {
		return null;
	} 

	public boolean ehIgual(Polinomio p) {
		return true;	
	}

}
