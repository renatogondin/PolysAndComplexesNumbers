
// Nao se esqueca de comentar a classe!
public class RunSemana3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//deve criar objectos Complexos e Polinomio para testar as operacoes sobre
		//complexos e sobre os polinomios.
	}

}
