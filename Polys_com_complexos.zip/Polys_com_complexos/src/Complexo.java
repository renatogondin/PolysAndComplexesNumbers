
// Nao se esqueca de comentar a classe!
public class Complexo {


    public static final double ERRO = 0.00001; 


    public Complexo ( double re, double im ) {
    }

    public double im () {
    	return 0.0;
    }

    public double re () {
    	return 0.0;
    }

    public double rho () {
    	return 0.0;
    }


    public double theta () {
        return 0.0;
    }

    public double norma () {
        return 0.0;
    }

    public Complexo soma (Complexo outro) {
    	return null;
    }

    public Complexo produto (Complexo outro) {
    	return null;
    }

    public Complexo quociente (Complexo outro) {
        return null;
    }


    public Complexo conjugado () {
        return null;
    }

    public boolean ehReal () {
        return true;
    }


    public boolean ehZero () {
        return true;
    }

    public boolean ehIgual(Complexo outro) {
        return true;
    }

    public String toString() {
        return null;
    }

    public String repTrignometrica() {
        return null; 
    }


    public Complexo potencia(double x) {
    	return null;
    }

}

