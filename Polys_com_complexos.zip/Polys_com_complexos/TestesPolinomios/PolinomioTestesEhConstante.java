import static org.junit.Assert.*;

import org.junit.Test;

public class PolinomioTestesEhConstante {

    private Polinomio p;


    
    @Test(timeout = 1000)
    public void grau0NaoEhZero () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(3,2);
        p = new Polinomio (coefs);
        assertTrue(p.ehConstante());
    }
    
    @Test(timeout = 1000)
    public void grau0EhZero () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(0,1);
        p = new Polinomio (coefs);
        assertTrue(p.ehConstante());
    }
    
    @Test(timeout = 1000)
    public void grauMaior0 () {
        Complexo[] coefs= new Complexo[4];
        coefs[0] = new Complexo(1,1);
        coefs[1] = coefs[0];
        coefs[2] = coefs[0];
        coefs[3] = coefs[0];
        p = new Polinomio (coefs);
        assertTrue(!p.ehConstante());
    }
    
}
