import static org.junit.Assert.*;

import org.junit.Test;

public class PolinomioTestesSubtraccao {

    private Polinomio p1;
    private Polinomio p2;
    private Polinomio esperado;
    private Polinomio obtido;

    @Test(timeout = 1000)
    public void AmbosGrau0 () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        p2 = new Polinomio (coefs);
        coefs[0] = new Complexo(0,1);
        esperado = new Polinomio (coefs);
        obtido = p1.subtraccao(p2);
        assertTrue(esperado.ehIgual(obtido));
    }
    
    @Test(timeout = 1000)
    public void AmbosGrau0Diferentes () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        
        coefs[0] = new Complexo(1,2);
        p2 = new Polinomio (coefs);
        
        coefs[0] = new Complexo(2,0);
        esperado = new Polinomio (coefs);
        obtido = p1.subtraccao(p2);
        assertTrue(esperado.ehIgual(obtido));
    }
    
    @Test(timeout = 1000)
    public void AmbosGrau1Iguais () {
        Complexo[] coefs= new Complexo[2];
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        p2 = new Polinomio (coefs);
        coefs[0] = new Complexo(3,1);
        coefs[1] = new Complexo(3,2);
       
        coefs= new Complexo[1];
        coefs[0] = new Complexo(0,1);
        esperado = new Polinomio (coefs);
        obtido = p1.subtraccao(p2);
        
        assertTrue(esperado.ehIgual(obtido));
    }
    
    @Test(timeout = 1000)
    public void AmbosGrau1Diferentes () {
        Complexo[] coefs= new Complexo[2];
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        
        coefs[0] = new Complexo(1,2);
        coefs[1] = new Complexo(0,1);
        p2 = new Polinomio (coefs);
        

        coefs[0] = new Complexo(2,0);
        coefs[1] = new Complexo(3,1);
        esperado = new Polinomio (coefs);
        obtido = p1.subtraccao(p2);
        assertTrue(esperado.ehIgual(obtido));
    }
    
    
    @Test(timeout = 1000)
    public void AmbosGrauMaior1Diferentes () {
        Complexo[] coefs= new Complexo[3];
        coefs[0] = new Complexo(2,1);
        coefs[1] = new Complexo(2,1);
        coefs[2] = new Complexo(1,1);
        p1 = new Polinomio (coefs);
        
        coefs[0] = new Complexo(0,1);
        coefs[1] = new Complexo(0,1);
        coefs[2] = new Complexo(1,1);
        p2 = new Polinomio (coefs);
        
        coefs= new Complexo[2];
        coefs[0] = new Complexo(2,0);
        coefs[1] = new Complexo(2,0);
        esperado = new Polinomio (coefs);
        obtido = p1.subtraccao(p2);
        assertTrue(esperado.ehIgual(obtido));
    }
    
    
}
