import static org.junit.Assert.*;

import org.junit.Test;

public class PolinomioTestesEhIgual {

    private Polinomio p1;
    private Polinomio p2;

    @Test(timeout = 1000)
    public void grau0Igual () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        p2 = new Polinomio (coefs);
        assertTrue(p1.ehIgual(p2));
    }
    
    @Test(timeout = 1000)
    public void grau0Equivalente () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        coefs[0] = new Complexo(6,4);
        p2 = new Polinomio (coefs);
        assertTrue(!p1.ehIgual(p2));
    }
  
    @Test(timeout = 1000)
    public void grau0NaoIgual () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        coefs[0] = new Complexo(6,5);
        p2 = new Polinomio (coefs);
        assertTrue(!p1.ehIgual(p2));
    }
    
    
    @Test(timeout = 1000)
    public void grau1Igual () {
        Complexo[] coefs= new Complexo[2];
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(1,1);
        p1 = new Polinomio (coefs);
        p2 = new Polinomio (coefs);
        assertTrue(p1.ehIgual(p2));
    }
    
    @Test(timeout = 1000)
    public void grauMaior1Iguais () {
        Complexo[] coefs= new Complexo[2];
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(1,1);
        p1 = new Polinomio (coefs);
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(1,1);
        p2 = new Polinomio (coefs);
        assertTrue(p1.ehIgual(p2));
    }
  
    @Test(timeout = 1000)
    public void grau1NaoIguais () {
        Complexo[] coefs= new Complexo[2];
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        coefs[0] = new Complexo(6,5);
        coefs[1] = new Complexo(3,2);
        p2 = new Polinomio (coefs);
        assertTrue(!p1.ehIgual(p2));
    }
}
