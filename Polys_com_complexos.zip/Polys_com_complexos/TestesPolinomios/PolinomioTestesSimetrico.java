import static org.junit.Assert.*;

import org.junit.Test;

public class PolinomioTestesSimetrico {

    private Polinomio p1;
    private Polinomio esperado;
    private Polinomio obtido;

    @Test(timeout = 1000)
    public void grau0 () {
        Complexo[] coefs= new Complexo[1];
        coefs[0] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        coefs[0] = new Complexo(-3,-2);
        esperado = new Polinomio (coefs);
        obtido = p1.simetrico();

        assertTrue(esperado.ehIgual(obtido));
    }
    
    @Test(timeout = 1000)
    public void grau1 () {
        Complexo[] coefs= new Complexo[2];
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(3,2);
        p1 = new Polinomio (coefs);
        
        coefs[0] = new Complexo(-3,-2);
        coefs[1] = new Complexo(-3,-2);
        esperado = new Polinomio (coefs);
        obtido = p1.simetrico();
       
        assertTrue(esperado.ehIgual(obtido));
    }
    
    @Test(timeout = 1000)
    public void grauMaior1 () {
        Complexo[] coefs= new Complexo[3];
        
        coefs[0] = new Complexo(3,2);
        coefs[1] = new Complexo(0,1);
        coefs[2] = new Complexo(1,1);
        p1 = new Polinomio (coefs);
        
        coefs[0] = new Complexo(-3,-2);
        coefs[1] = new Complexo(0,-1);
        coefs[2] = new Complexo(-1,-1);
        
        esperado = new Polinomio (coefs);
        obtido = p1.simetrico();
        assertTrue(esperado.ehIgual(obtido));
    }
    
}
